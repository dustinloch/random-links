package randomLinks;

import java.util.ArrayList;

public interface Topology {
	
	public void addRandomLinks(int degree);
	
	public ArrayList getNodes();

}
