package randomLinks;

import java.util.Scanner;
/**
 * This code is really pretty ugly, so sorry, but I didn't have time to make it pretty. But it does work
 * so thats nice
 */
public class Main {
	
	private static int node;
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("How mant nodes you want?");
		node = scan.nextInt();
		System.out.println("what degree of random links do you want on your nodes?");
		int deg = scan.nextInt();
		Ring r1 = new Ring(node);
		
		Analysis a1 = new Analysis(r1);
		System.out.println("the diameter of a " + node + " node Ring is ");
		a1.countDiameter();
		System.out.println("the diameter of a " + node + " node Ring is with "+deg+" random links is");
		r1.addRandomLinks(deg);
		a1.countDiameter();
		System.out.println("the average path length of a " + node + " node Ring is with"
				+ " "+deg+" random links is");
		a1.countAvgPath();
		
		scan.close();
		

	}

}
