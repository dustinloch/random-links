package randomLinks;

import java.util.HashSet;

public class Node implements Comparable<Node>{
	//private HashSet<Edge> Edges;
	private HashSet<Node> Neighbors;
	
	public Node(){
		//Edges = new HashSet();
		Neighbors = new HashSet();
	}
	


	public HashSet<Node> getNeighbors() {
		return Neighbors;
	}

	public void addNeighbor(Node neighbor) {
		Neighbors.add(neighbor);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		return false;
	}


	@Override
	public int compareTo(Node o) {
		return 1;
	}
	
}
