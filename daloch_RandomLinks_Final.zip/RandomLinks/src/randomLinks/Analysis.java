package randomLinks;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.TreeSet;

public class Analysis {
	
	private Topology graph;
	private HashSet<Node> visited;
	private HashSet<Node> togo;
	private int avg;
	
	public Analysis(Topology grap){
		graph = grap;
		visited = new HashSet<Node>(grap.getNodes().size());
		togo = new HashSet<Node>();
		avg = 0;
	}
	
	@SuppressWarnings("unchecked")
	public int recursionPart(int diam){
		if(visited.size() >= graph.getNodes().size() || togo.size() == 0){
			return diam;
		}
		
		//have to temp swap to avoid fucking with togo while im iterating through it
		
		//I realize there are almost certainly faster ways to do this then copy everything over 
		//then run through ever node like 10 times, but this was all I could think of
		//and it works well for rings
		HashSet<Node> temp = (HashSet<Node>) togo.clone();
		for(Node s : togo){
			//if not visited, visit it, stick it neighbors in togo
			if(!visited.contains(s)){
				visited.add(s);
				HashSet<Node> greg = s.getNeighbors();
				temp.addAll(greg);
			}
		temp.remove(s);
		}
		//after getting all the next neighbors set up, we get to call this step done and inc diameter
		diam++;
		//and switch back
		togo = (HashSet<Node>) temp.clone();
		
		if(togo.size() > 0){
			
			return recursionPart(diam);
		}
		else
			return diam;
		
	}
	public void countDiameter(){
		//sets up for a modified dykstras
		ArrayList<Node> nodes = graph.getNodes();
		int diam = -1;
		visited.clear();
		togo.clear();
		TreeSet<Integer> diameters = new TreeSet<Integer>();
		
		for(Node n : nodes){
			//runs modified dykstras and pulls out the longest path
			togo.add(n);
			diameters.add(recursionPart(diam));
		}
		//actually is the part that pulls out the longest path
		System.out.println(diameters.last());
	}
	
	
	public void countAvgPath(){
		//sets up for a modified dykstras
				@SuppressWarnings("unchecked")
				ArrayList<Node> nodes = (ArrayList<Node>) graph.getNodes();
				int diam = -1;
				visited.clear();
				togo.clear();
				TreeSet<Integer> diameters = new TreeSet<Integer>();
				
				for(Node n : nodes){
					//runs modified dykstras and pulls out the longest path
					togo.add(n);
					diameters.add(recursionPart2(diam));
				}
				//actually is the part that pulls out the longest path
				System.out.println(avg/nodes.size());
		
	}
	public int recursionPart2(int diam){
		if(visited.size() >= graph.getNodes().size() || togo.size() == 0){
			return diam;
		}
		
		//have to temp swap to avoid fucking with togo while im iterating through it
		
		//I realize there are almost certainly faster ways to do this then copy everything over 
		//then run through ever node like 10 times, but this was all I could think of
		//and it works well for rings
		HashSet<Node> temp = (HashSet<Node>) togo.clone();
		for(Node s : togo){
			//if not visited, visit it, stick it neighbors in togo
			if(!visited.contains(s)){
				visited.add(s);
				avg = avg + diam;
				HashSet<Node> greg = s.getNeighbors();
				temp.addAll(greg);
			}
		temp.remove(s);
		}
		//after getting all the next neighbors set up, we get to call this step done and inc diameter
		diam++;
		//and switch back
		togo = (HashSet<Node>) temp.clone();
		
		if(togo.size() > 0){
			
			return recursionPart2(diam);
		}
		else
			return diam;
		
	}

}
