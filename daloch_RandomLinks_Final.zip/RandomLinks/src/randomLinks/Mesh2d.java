package randomLinks;

import java.util.ArrayList;

public class Mesh2d {
	
	private int numNodes;
	private ArrayList<ArrayList<Node>> shit;
	
	public Mesh2d(int n){
		numNodes = n^2;
		shit = new ArrayList<ArrayList<Node>>();
		
		for(int i = 0; i < n; i++){
			for(int j = 0; j < n; i++){
				ArrayList<Node> temp = shit.get(i);
				temp.add(new Node());
			}
		}
		
		
	}

	public void addRandomLinks(int degree){
		if(numNodes<5){
			System.out.println("you asshat theres not point in doing this");
			return;
		}
		if(degree < 1){
			System.out.println("wrong input for addRandomLinks degree, no links added");
			return;
		}
		if(degree+2 > numNodes/2){
			System.out.println("you've made a complete graph. Congradulations you've spent all your money on wires and now you're poor");
			return;
		}
		//every node in shit
		for(ArrayList<Node> a : shit){
			for(Node nod : a){
				//take a random new neighbor to it
				int prevnei = nod.getNeighbors().size();
				for(int i = 0; i < degree; i++){
				
					int x = (int) (Math.random()*numNodes);
					nod.addNeighbor(shit.get(x).get((int) (Math.random()*numNodes)));
					if(nod.getNeighbors().size() <= prevnei)
						i--;
					else
						prevnei++;
				}
			
			}
		}

	}
	
	
}
