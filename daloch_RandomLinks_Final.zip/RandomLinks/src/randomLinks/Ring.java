package randomLinks;

import java.util.ArrayList;

public class Ring implements Topology{
	private int numNodes;
	
	public int getNumNodes() {
		return numNodes;
	}

	private ArrayList<Node> shit;
	
	public Ring(int n){
		this.numNodes = n;
		shit = new ArrayList<Node>();
		//shit now full of nodes
		for(int i = 0; i < n; i++){
			shit.add(new Node());
		}
		//nodes now full of edges (special case for the first and last so it loops all sexy-like)
		for(Node nod : shit){
			if(shit.indexOf(nod)!= 0 && shit.indexOf(nod)!=n-1){
				//connects all the dots
				nod.addNeighbor(shit.get(shit.indexOf(nod)-1));
				nod.addNeighbor(shit.get(shit.indexOf(nod)+1));
			}
			if(shit.indexOf(nod)==0){
				//loops the beginning
				nod.addNeighbor(shit.get(n-1));
				nod.addNeighbor(shit.get(1));
			}
			if(shit.indexOf(nod)==n-1){
				//loops the end
				nod.addNeighbor(shit.get(shit.indexOf(nod)-1));
				nod.addNeighbor(shit.get(0));
			}
		}
	}
	
	public void addRandomLinks(int degree){
		if(numNodes<5){
			System.out.println("you asshat theres not point in doing this");
			return;
		}
		if(degree < 1){
			System.out.println("wrong input for addRandomLinks degree, no links added");
			return;
		}
		if(degree+2 > numNodes/2 || numNodes == 5){
			System.out.println("you've made a complete graph. Congradulations you've spent all your money on wires and now you're poor");
			return;
		}
		//every node in shit
		for(Node nod : shit){
			//take a random new neighbor to it
			for(int i = 0; i < degree; i++){
				int x = (int) (Math.random()*numNodes);
				nod.addNeighbor(shit.get(x));
				if(nod.getNeighbors().size() <= i+2){
					i--;
				}
			}
			
		}
	}


	@Override
	public ArrayList<Node> getNodes() {
		return shit;
	}
	
}
